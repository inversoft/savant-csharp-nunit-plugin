using System.Reflection;

[AssemblyCompany("Inversoft")]
[AssemblyCopyright("Copyright (c) 2016, Inversoft, Licensed under the Apache v2.0 license")]
[AssemblyDescription("The assembly used for testing the C# NUnit plugin")]
[AssemblyProduct("Savant C# NUnit Plugin")]
[AssemblyTitle("Savant C# NUnit Plugin Test")]
[AssemblyVersion("1.0.0")]
